package com.example.uasandroidperpus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class Editpeminjaman extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editpeminjaman);

        // Mendapatkan referensi ke Spinner
        Spinner spinnerStatus = findViewById(R.id.spinnerStatus);

        // Daftar opsi status
        String[] statusOptions = {"Dipinjam", "Dikembalikan"};

        // Buat adapter untuk Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, statusOptions);

        // Set adapter ke Spinner
        spinnerStatus.setAdapter(adapter);
    }
}