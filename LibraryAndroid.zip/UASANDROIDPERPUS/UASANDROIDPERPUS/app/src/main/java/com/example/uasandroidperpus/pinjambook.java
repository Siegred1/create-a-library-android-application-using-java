package com.example.uasandroidperpus;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;

public class pinjambook extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pinjambook);

    }
}